$(document).ready(function(){

   $(".img_id1").mousemove(function(e){
      
   	$("#show_here").attr("src",$(this).attr("src")); 
   	$("#show_here").css("marginTop",-((e.clientY*10)-($(".view_container_img").offset().top)*13));
   	 $("#show_here").css("marginLeft",-((e.clientX*21)-($(".view_container_img").offset().left)*3));
   	$("#show_here").addClass("show_class");
   	$(".view_container_img").addClass("showfull");


   }); $(".img_id2").mousemove(function(e){
      
   	$("#show_here").attr("src",$(this).attr("src")); 
   	$("#show_here").css("marginTop",-(((e.clientY-200)*10)-($(".view_container_img").offset().top)*13));
   	 $("#show_here").css("marginLeft",-((e.clientX*21)-($(".view_container_img").offset().left)*3));
   	$("#show_here").addClass("show_class");
   	$(".view_container_img").addClass("showfull");


   });
    $(".img_id").mouseout(function(e){
    		$(".view_container_img").removeClass("showfull");

  });

  $("#ok_click").click(function(e){

     var data1 = $("#input_data").val();
     var data2 = $("#input_data").val();
    
    if(data1==''){
     console.log("Please fill somethings ..");
    }else{

        
         $(".bubble_container2").append('<div class="bubble">'+data1
          +'</div>');
           $(".bubble").addClass("show_bubble");
       console.log( $(".bubble_container2"));
      }

       
  });

});