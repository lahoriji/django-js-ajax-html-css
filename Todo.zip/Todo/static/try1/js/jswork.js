$(document).ready(function(){

   $("body").delegate("#Search_Id","keyup",function(e){
    e.preventDefault();
   
   var myKey = $('#Search_Id').val();

       $.ajax({

      url:'',
      type:'POST',
      data:{myKey,
        csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
      },
      success:function(response){
        if(myKey!=""){
           $('#show_live').html(response);
        }else{
           $('#show_live').html(" ");
        }
       
         
      }


    });




  });


  $("body").delegate("#Calculate_id","click",function(e){

     e.preventDefault();
      var age = $('#myage_id').val();

        $.ajax({

      url:'',
      type:'GET',
      data:{age,
        csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
      },
      success:function(response){
        
         
      }


    });



  });

  $('#Add').click(function(e){
    e.preventDefault();
  		var data_all = $('#text_data').val();

  	$.ajax({

  		url:'',
  		type:'POST',
  		data:{data_all,
  			csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
  		},
  		success:function(response){
  			 loads();
  			 
  		}


  	});		

  });

  function loads(){
    
    var limit=10
  	$.ajax({

  		url:"/result/",
  		type:'GET',
  		data:{csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()},
  		success:function(response){
  			$('#hole_data').html(response);
  			
  		}


  	});		


  }
 //setInterval(function(){loads();},2000);


   $('body').delegate('#Delete_the_items','click',function(){

      $("#PopUp").addClass('showClass');

      
      var ids = $('#Delete_the_items').attr('tag');
      if($('#yes_id').click(function(){
         setTimeout(function(){del(ids);},1000);
         $("#PopUp").removeClass('showClass');
      }));
         if($('#no_id').click(function(){
         $("#PopUp").removeClass('showClass');

      }));
     

   });

   function del(ids){
     $.ajax({

      url:"/delete/",
      type:'GET',
      data:{ids:ids,csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()},
      success:function(response){
        
         loads();
         
        
      }


    }); 
   }

   loads();
});