import time

def cal(dob):
	
	return True

