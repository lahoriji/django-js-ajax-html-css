from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
from django.db.models import Q
from .models import Titles
from . import function

# Create your views here.

def index(request):
	if request.method=='POST' and request.is_ajax:
		t = request.POST.get('data_all')
		table = Titles(title=t)
		table.save()
	return render(request,'try1/main.html')



def result(request):
	li = Titles.objects.all()
	return render(request,'try1/result.html',{"obj":li})
	

def delete(request):
	ids=request.GET.get('ids')
	t = Titles.objects.get(id=ids)
	t.delete()
	return render(request,'try1/delete.html',{'msg':"successfully deleted"})

def ageCal(request):
	if request.method=="GET":
		age = request.GET.get('age')
		year = function.cal(age)
		print(year)
	return render(request,'try1/AgeCalculation.html')


def liveSearch(request):
	if request.method=="POST":
		val=request.POST.get('myKey')
		val2 = Titles.objects.filter(Q(title__contains=val)|Q(title__icontains=val))
		collect = {
		"list_search":val2
		}
		return render(request,'try1/backResponseLive.html',collect)
	return render(request,'try1/live.html')