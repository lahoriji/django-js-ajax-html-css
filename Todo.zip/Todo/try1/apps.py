from django.apps import AppConfig


class Try1Config(AppConfig):
    name = 'try1'
